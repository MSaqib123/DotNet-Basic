# Computer Shop

Really, really simple console based application

## Functionalities:

- [x] New Order
- [x] Add PC item
- [x] Modify order
- [x] List orders
